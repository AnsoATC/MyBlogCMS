<?php

namespace App\DataFixtures;

use App\Entity\Option;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;

class OptionFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        $options[] = new Option('Blog title', 'blog_title', 'My blog', TextType::class);
        $options[] = new Option('About', 'about', 'About us', TextareaType::class);
        $options[] = new Option('Copyright text', 'blog_copyright', 'All rights reserved', TextType::class);
        $options[] = new Option("Number of articles per page", "blog_articles_limit", 5, NumberType::class);
        $options[] = new Option("Anyone can register", "users_can_register", true, CheckboxType::class);

        foreach ($options as $option) {
            $manager->persist($option);
        }

        $manager->flush();
    }
}