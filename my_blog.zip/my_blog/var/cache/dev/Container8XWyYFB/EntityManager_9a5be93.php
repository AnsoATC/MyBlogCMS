<?php

namespace Container8XWyYFB;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'src'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder18617 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerc645d = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiescef11 = [
        
    ];

    public function getConnection()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'getConnection', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'getMetadataFactory', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'getExpressionBuilder', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'beginTransaction', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'getCache', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->getCache();
    }

    public function transactional($func)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'transactional', array('func' => $func), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'wrapInTransaction', array('func' => $func), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'commit', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->commit();
    }

    public function rollback()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'rollback', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'getClassMetadata', array('className' => $className), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'createQuery', array('dql' => $dql), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'createNamedQuery', array('name' => $name), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'createQueryBuilder', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'flush', array('entity' => $entity), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'clear', array('entityName' => $entityName), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->clear($entityName);
    }

    public function close()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'close', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->close();
    }

    public function persist($entity)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'persist', array('entity' => $entity), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'remove', array('entity' => $entity), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'refresh', array('entity' => $entity), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'detach', array('entity' => $entity), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'merge', array('entity' => $entity), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'getRepository', array('entityName' => $entityName), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'contains', array('entity' => $entity), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'getEventManager', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'getConfiguration', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'isOpen', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'getUnitOfWork', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'getProxyFactory', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'initializeObject', array('obj' => $obj), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'getFilters', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'isFiltersStateClean', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'hasFilters', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return $this->valueHolder18617->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerc645d = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder18617) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder18617 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder18617->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, '__get', ['name' => $name], $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        if (isset(self::$publicPropertiescef11[$name])) {
            return $this->valueHolder18617->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder18617;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder18617;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder18617;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder18617;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, '__isset', array('name' => $name), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder18617;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder18617;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, '__unset', array('name' => $name), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder18617;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder18617;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, '__clone', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        $this->valueHolder18617 = clone $this->valueHolder18617;
    }

    public function __sleep()
    {
        $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, '__sleep', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;

        return array('valueHolder18617');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerc645d = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerc645d;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerc645d && ($this->initializerc645d->__invoke($valueHolder18617, $this, 'initializeProxy', array(), $this->initializerc645d) || 1) && $this->valueHolder18617 = $valueHolder18617;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder18617;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder18617;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
